package com.aydsii.tp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
